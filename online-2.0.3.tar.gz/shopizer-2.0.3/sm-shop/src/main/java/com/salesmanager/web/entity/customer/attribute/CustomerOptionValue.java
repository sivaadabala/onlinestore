package com.salesmanager.web.entity.customer.attribute;

import java.io.Serializable;

import com.salesmanager.web.entity.Entity;

public class CustomerOptionValue extends Entity implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}

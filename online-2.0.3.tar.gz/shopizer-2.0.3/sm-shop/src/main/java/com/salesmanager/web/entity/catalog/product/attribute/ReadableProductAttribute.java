package com.salesmanager.web.entity.catalog.product.attribute;

import java.io.Serializable;

public class ReadableProductAttribute extends ProductAttributeEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

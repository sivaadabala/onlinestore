package com.salesmanager.web.entity.shop;

public enum BreadcrumbItemType {
	
	CATEGORY, PRODUCT, HOME, PAGE

}

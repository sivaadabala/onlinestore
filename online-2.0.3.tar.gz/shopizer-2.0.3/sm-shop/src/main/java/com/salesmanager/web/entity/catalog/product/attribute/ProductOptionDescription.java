package com.salesmanager.web.entity.catalog.product.attribute;

import java.io.Serializable;

import com.salesmanager.web.entity.catalog.CatalogEntity;

public class ProductOptionDescription extends CatalogEntity implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

package com.salesmanager.web.entity.order;

import java.io.Serializable;

import com.salesmanager.web.entity.Entity;

public class Order extends Entity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

package com.salesmanager.core.modules.cms.product;




public abstract class  ProductFileManager implements ProductImagePut, ProductImageGet, ProductImageRemove {
	
	


}

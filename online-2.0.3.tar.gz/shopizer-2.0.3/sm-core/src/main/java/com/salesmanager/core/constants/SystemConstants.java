package com.salesmanager.core.constants;

public class SystemConstants {
	
	

	public final static String SYSTEM_USER = "SYSTEM";
	public final static String CONFIG_VALUE_TRUE = "true";
	public final static String CONFIG_VALUE_FALSE = "false";

}

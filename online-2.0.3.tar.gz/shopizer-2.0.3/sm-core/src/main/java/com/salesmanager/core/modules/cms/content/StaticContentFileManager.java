/**
 * 
 */
package com.salesmanager.core.modules.cms.content;

/**
 * @author Umesh Awasthi
 *
 */
public abstract class StaticContentFileManager implements FileGet,FilePut,FileRemove
{

}

package com.salesmanager.core.business.system.model;

public enum Module {
	
	PAYMENT, SHIPPING

}

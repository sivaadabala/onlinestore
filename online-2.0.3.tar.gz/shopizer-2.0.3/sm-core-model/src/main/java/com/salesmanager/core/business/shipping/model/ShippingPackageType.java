package com.salesmanager.core.business.shipping.model;

public enum ShippingPackageType {
	
	ITEM, BOX

}

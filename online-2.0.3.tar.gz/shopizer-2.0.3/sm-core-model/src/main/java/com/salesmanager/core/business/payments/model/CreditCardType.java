package com.salesmanager.core.business.payments.model;

public enum CreditCardType {
	
	AMEX, VISA, MASTERCARD, DINERS, DISCOVERY

}

package com.salesmanager.core.business.order.model;

public enum OrderTotalType {
	
	SHIPPING, HANDLING, TAX, PRODUCT, SUBTOTAL, TOTAL, CREDIT, REFUND

}

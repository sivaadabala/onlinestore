package com.salesmanager.core.business.customer.model;

public enum CustomerGender {
	
	M, F

}

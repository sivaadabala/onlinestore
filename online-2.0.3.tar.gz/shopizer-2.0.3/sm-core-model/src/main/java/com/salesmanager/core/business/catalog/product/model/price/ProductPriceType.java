package com.salesmanager.core.business.catalog.product.model.price;

public enum ProductPriceType {
	
	ONE_TIME, MONTHLY

}

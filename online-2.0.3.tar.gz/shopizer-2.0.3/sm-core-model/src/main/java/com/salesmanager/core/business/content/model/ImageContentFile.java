package com.salesmanager.core.business.content.model;

import java.io.Serializable;

public class ImageContentFile extends InputContentFile implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5321162403524229224L;
	//private BufferedImage bufferedImage;

	//public void setBufferedImage(BufferedImage bufferedImage) {
	//	this.bufferedImage = bufferedImage;
	//}

	//public BufferedImage getBufferedImage() {
	//	return bufferedImage;
	//}
}

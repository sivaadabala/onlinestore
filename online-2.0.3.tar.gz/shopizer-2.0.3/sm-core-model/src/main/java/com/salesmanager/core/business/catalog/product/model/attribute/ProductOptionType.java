package com.salesmanager.core.business.catalog.product.model.attribute;

public enum ProductOptionType {
	
	Text, Radio, Select, Checkbox

}

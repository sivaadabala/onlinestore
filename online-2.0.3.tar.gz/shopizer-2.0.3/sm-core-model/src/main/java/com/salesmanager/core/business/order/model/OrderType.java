package com.salesmanager.core.business.order.model;

public enum OrderType {
	
	ORDER, BOOKING

}
